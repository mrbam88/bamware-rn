// Only import react-native-gesture-handler on native platforms
// https://reactnavigation.org/docs/drawer-navigator/#installation
import "react-native-gesture-handler"
